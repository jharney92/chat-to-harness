# [project name]

Instruction file: AGENTS.md (Claude Code reads it through the import in CLAUDE.md; other agents read it directly).

## What this repository is
- [One sentence: what it does and for whom.] <!-- README.md -->
- [The main technologies and where data is stored.] <!-- package.json -->
- [What it deliberately does NOT do.] <!-- README.md -->

## Commands
- Run locally: [command] <!-- package.json scripts -->
- Run all tests: [command] <!-- package.json scripts -->
- Build: [command] <!-- package.json scripts -->

## Topology and env names
- [Where the app runs and where the data lives.]
- Secrets, by NAME only: [DATABASE_URL, ...] <!-- .env.example -->

## Tools
- git, gh, vercel, neon: use these directly instead of asking me to click through a dashboard.
- [your own commands, one line each]

## Invariants and deliberate behavior
- Every database read and write filters by the signed-in user. <!-- [file] -->
- [Anything that looks like a bug but is intentional.]

## Gates
- Tier 1, do it and report: edits on a branch, running tests, reading anything.
- Tier 2, tell me first: changing a schedule, adding a new outside service.
- Tier 3, wait for my yes: merging to main, spending over [2] dollars in one run, sending anything to a real person, deleting data, changing keys or access.
- Tier 4, decide and log it in DECISIONS.md: every other judgment call.

## Deployment and prohibitions
- A push or merge to main IS the production deploy. Work on a branch.
- Refer to secrets by name only. Never print, log or commit their values.
- Never run a migration that drops or renames a column without my yes.
- Every scheduled or background job reports failures to [where].
- One review per change, then ship. Do not re-review a fix unless it touches sending, spending or deleting.
- Nothing is done until it has been exercised on the running app.
