# Harness starter kit

Starter files from the guide "From Chat to Harness". Adapted from a working setup, with private details removed.

How to use it:
1. Copy CLAUDE.md, AGENTS.md and the .claude folder into the top of your project.
2. Fill in every [bracketed] part of AGENTS.md. Delete lines that do not apply.
3. Copy global-CLAUDE.md to the .claude folder in your home folder and rename it CLAUDE.md. Edit it until it sounds like you.
4. Make the guard runnable:  chmod +x .claude/hooks/guard.sh
5. Start Claude Code in the project and ask: "What must you never do in this project, and where does each rule come from?"

Check .claude/settings.json against the current Claude Code permissions and hooks documentation before relying on it. The format changes over time.

The files in templates/ are for you to copy as needed.
