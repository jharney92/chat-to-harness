#!/bin/bash
# Runs before every terminal command the agent wants to execute.
# Blocks two things:
#   1. A forced git push, which rewrites history on GitHub.
#   2. rm -r aimed at a path outside the project (starting with /, ~, $HOME or ..).
# Why it exists: [write your own reason and the date here]
# If anything in this script goes wrong, it ALLOWS the command.
# A broken guard must never block all work.

input=$(cat)
# Read the command out of the JSON that Claude Code sends. Node first
# (Module 7 installs it on Mac and Windows), then Python as a fallback.
cmd=$(printf '%s' "$input" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{process.stdout.write(String(JSON.parse(s).tool_input.command||""))}catch(e){}})' 2>/dev/null)
[ -n "$cmd" ] || cmd=$(printf '%s' "$input" | python3 -c 'import json,sys
try: print(json.load(sys.stdin).get("tool_input",{}).get("command",""))
except Exception: pass' 2>/dev/null)
[ -n "$cmd" ] || exit 0

if printf '%s' "$cmd" | grep -Eq '(^|[;&|[:space:]])git[[:space:]]+push([[:space:]]+[^;&|]*)?[[:space:]](--force|--force-with-lease|-f)([[:space:]]|$)'; then
  echo "Blocked by guard: a forced push rewrites history on GitHub. Ask the human first." >&2
  exit 2
fi

if printf '%s' "$cmd" | grep -Eq '(^|[;&|[:space:]])rm[[:space:]]+-[a-zA-Z]*[rR][a-zA-Z]*[[:space:]]+(/|~|\$HOME|\.\.)'; then
  echo "Blocked by guard: recursive delete outside the project folder. Use a path inside the project, or ask the human." >&2
  exit 2
fi

exit 0
