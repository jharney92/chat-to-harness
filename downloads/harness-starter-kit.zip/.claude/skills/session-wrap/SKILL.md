---
name: session-wrap
description: End-of-session routine. Run when I say "wrap up" or "done for today", or before I clear the session.
---
1. State check. Is anything half-done? Are there uncommitted changes or unpushed commits?
   Surface each with a recommendation. Do not silently leave them.
2. Memory. Update HANDOFF.md so a fresh session could resume cold from it.
   Prefer updating the existing note over creating a near-duplicate.
3. Status. Update STATUS.md: what is live, what is built but not checked, what is next.
4. Commit and push the notes.
5. Sign-off. One short summary: what shipped, what is verified, what is pending on me.
