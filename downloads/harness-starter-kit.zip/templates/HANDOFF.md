# Handoff: [project], [date]

Suggested name for the next session: [Project_WhatWeAreDoing]

## What we did
- [...]

## What works (checked on the live product)
- [...]

## Built but not yet checked
- [...]

## Unfinished
- [...]

## First thing to do next time
[one instruction]

## To undo the last merge
[the exact command]
