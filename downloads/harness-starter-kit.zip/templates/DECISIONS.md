# Decisions the agents made for me

Newest first. Any of these can be revisited.

## [date]: [what was decided]
- Choice: [...]
- Why: [...]
- Affects: [...]
- Undo: [...]
