# Decision needed: [title]

## The ask
[one sentence]

## Context
[what you need to know to answer, and nothing else]

## Options
A. [option]. Cost: [...]. Who sees it: [...]. Undo: [...].
B. [option]. Cost: [...]. Who sees it: [...]. Undo: [...].

## My pick
[A or B], because [...]

## If you do not answer
[what happens, and by when]
