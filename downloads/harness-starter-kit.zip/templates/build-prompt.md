You are implementing: [name of this piece of work]

Goal:
[one sentence]

Why this piece exists:
[one or two sentences]

Context:
[everything the agent needs, stated in full. Assume it has seen nothing.]

Files likely to change:
- [path]

Steps:
1. [...]
2. [...]

How to verify:
1. [command or check]
2. [command or check]

Done when:
- [testable line]
- [testable line]

Out of scope:
- [...]

I can:
[one line on what I can do on the live product after this]

Rules:
- Do not ask for more requirements unless you are truly blocked.
- Where a detail is missing, make a reasonable assumption and list it in your final summary.
- Finish the work end to end, including verification.
